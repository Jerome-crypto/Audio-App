import React, { useState, useCallback } from 'react';
import { FileAudio } from 'lucide-react';
import FileUploader from './components/FileUploader';
import VoiceSelector from './components/VoiceSelector';
import AudioPlayer from './components/AudioPlayer';
import { extractTextFromFile } from './utils/fileProcessing';
import { SpeechService } from './utils/speechSynthesis';

const speechService = new SpeechService();

function App() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedVoice, setSelectedVoice] = useState<'male' | 'female'>('male');
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Cleanup function for audio URL
  const cleanupAudioUrl = useCallback(() => {
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
      setAudioUrl(null);
    }
  }, [audioUrl]);

  const handleFileSelect = useCallback(async (file: File) => {
    setSelectedFile(file);
    setIsProcessing(true);
    setError(null);
    cleanupAudioUrl();
    
    try {
      // Extract text from the document
      const text = await extractTextFromFile(file);
      
      if (!text.trim()) {
        throw new Error('No text content found in document');
      }
      
      // Convert text to speech
      const audioBlob = await speechService.textToSpeech(text, {
        voice: selectedVoice,
        pitch: 1,
        rate: 1
      });
      
      // Create URL for the audio blob
      const url = URL.createObjectURL(audioBlob);
      setAudioUrl(url);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred');
      console.error('Error processing file:', err);
    } finally {
      setIsProcessing(false);
    }
  }, [selectedVoice, cleanupAudioUrl]);

  // Cleanup on unmount
  React.useEffect(() => {
    return () => {
      cleanupAudioUrl();
    };
  }, [cleanupAudioUrl]);

  const handleDownload = useCallback(() => {
    if (audioUrl && selectedFile) {
      const link = document.createElement('a');
      link.href = audioUrl;
      link.download = `${selectedFile.name.split('.')[0]}.mp3`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }, [audioUrl, selectedFile]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex justify-center mb-4">
              <FileAudio className="w-16 h-16 text-blue-500" />
            </div>
            <h1 className="text-4xl font-bold text-gray-800 mb-4">
              Document to Speech Converter
            </h1>
            <p className="text-gray-600">
              Transform your documents into natural-sounding audio files
            </p>
          </div>

          {/* Main Content */}
          <div className="space-y-8">
            <FileUploader onFileSelect={handleFileSelect} />

            {error && (
              <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-red-700">{error}</p>
                  </div>
                </div>
              </div>
            )}

            {selectedFile && !error && (
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <p className="text-sm text-gray-600 mb-2">Selected file:</p>
                <p className="font-medium text-gray-800">{selectedFile.name}</p>
              </div>
            )}

            <VoiceSelector
              selectedVoice={selectedVoice}
              onVoiceChange={(voice) => setSelectedVoice(voice as 'male' | 'female')}
            />

            {isProcessing && (
              <div className="text-center p-4">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
                <p className="mt-4 text-gray-600">Processing your document...</p>
              </div>
            )}

            {audioUrl && !isProcessing && (
              <AudioPlayer audioUrl={audioUrl} onDownload={handleDownload} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;