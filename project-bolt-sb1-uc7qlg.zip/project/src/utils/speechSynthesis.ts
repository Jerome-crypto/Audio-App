export interface VoiceOptions {
  voice: 'male' | 'female';
  pitch?: number;
  rate?: number;
}

export class SpeechService {
  private synthesis: SpeechSynthesis;
  private voices: SpeechSynthesisVoice[];

  constructor() {
    this.synthesis = window.speechSynthesis;
    this.voices = [];
  }

  async initialize(): Promise<void> {
    if (this.voices.length === 0) {
      // Wait for voices to be loaded
      await new Promise<void>((resolve) => {
        if (this.synthesis.getVoices().length > 0) {
          this.voices = this.synthesis.getVoices();
          resolve();
        } else {
          this.synthesis.onvoiceschanged = () => {
            this.voices = this.synthesis.getVoices();
            resolve();
          };
        }
      });
    }
  }

  async textToSpeech(text: string, options: VoiceOptions): Promise<Blob> {
    await this.initialize();

    return new Promise((resolve, reject) => {
      const utterance = new SpeechSynthesisUtterance(text);
      
      // Select voice based on gender preference
      const voice = this.voices.find(v => 
        options.voice === 'female' 
          ? v.name.toLowerCase().includes('female') 
          : v.name.toLowerCase().includes('male')
      ) || this.voices[0];

      utterance.voice = voice;
      utterance.pitch = options.pitch || 1;
      utterance.rate = options.rate || 1;

      // Use MediaRecorder to capture the audio
      const audioChunks: Blob[] = [];
      const audioContext = new AudioContext();
      const mediaStreamDestination = audioContext.createMediaStreamDestination();
      
      // Create audio element to play the speech
      const audio = new Audio();
      audio.srcObject = mediaStreamDestination.stream;
      
      const mediaRecorder = new MediaRecorder(mediaStreamDestination.stream);
      
      mediaRecorder.ondataavailable = (event) => {
        audioChunks.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/mp3' });
        resolve(audioBlob);
      };

      mediaRecorder.start();
      this.synthesis.speak(utterance);

      utterance.onend = () => {
        mediaRecorder.stop();
        audioContext.close();
      };

      utterance.onerror = (error) => {
        reject(error);
      };
    });
  }
}