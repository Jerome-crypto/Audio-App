import * as PDFJS from 'pdfjs-dist';
import * as mammoth from 'mammoth';

// Initialize PDF.js worker
const pdfjsWorker = await import('pdfjs-dist/build/pdf.worker.mjs');
PDFJS.GlobalWorkerOptions.workerSrc = pdfjsWorker;

export async function extractTextFromFile(file: File): Promise<string> {
  if (!file) {
    throw new Error('No file provided');
  }

  const fileType = file.name.split('.').pop()?.toLowerCase();
  const maxFileSize = 10 * 1024 * 1024; // 10MB limit
  
  if (file.size > maxFileSize) {
    throw new Error('File size exceeds 10MB limit');
  }
  
  try {
    switch (fileType) {
      case 'pdf':
        return await extractFromPDF(file);
      case 'docx':
        return await extractFromDOCX(file);
      case 'ppt':
      case 'pptx':
        throw new Error('PPT processing not implemented yet');
      default:
        throw new Error(`Unsupported file type: ${fileType}`);
    }
  } catch (error: any) {
    console.error('Error processing file:', error);
    throw new Error(
      error.message || 'An unexpected error occurred while processing the file'
    );
  }
}

async function extractFromPDF(file: File): Promise<string> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const typedArray = new Uint8Array(arrayBuffer);
    
    const loadingTask = PDFJS.getDocument({
      data: typedArray,
      useWorkerFetch: true,
      isEvalSupported: true,
      useSystemFonts: true,
      standardFontDataUrl: `https://unpkg.com/pdfjs-dist@${PDFJS.version}/standard_fonts/`,
    });

    const pdf = await loadingTask.promise;
    let text = '';

    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      const pageText = content.items
        .map((item: any) => item.str || '')
        .join(' ')
        .trim();
      
      if (pageText) {
        text += pageText + '\n\n';
      }
    }

    const cleanedText = text.trim();
    if (!cleanedText) {
      throw new Error('No readable text found in PDF');
    }

    return cleanedText;
  } catch (error: any) {
    console.error('PDF extraction error:', error);
    if (error.name === 'PasswordException') {
      throw new Error('This PDF is password protected');
    } else if (error.name === 'InvalidPDFException') {
      throw new Error('Invalid or corrupted PDF file');
    } else if (error.name === 'MissingPDFException') {
      throw new Error('Could not load PDF file');
    } else if (error.message.includes('Worker')) {
      throw new Error('PDF processing initialization failed');
    } else {
      throw new Error('Could not extract text from PDF. Please ensure the file contains readable text.');
    }
  }
}

async function extractFromDOCX(file: File): Promise<string> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer });
    
    const cleanedText = result.value.trim();
    if (!cleanedText) {
      throw new Error('No readable text found in DOCX');
    }
    
    return cleanedText;
  } catch (error: any) {
    console.error('DOCX extraction error:', error);
    throw new Error(
      'Could not extract text from DOCX. Please ensure the file is not corrupted.'
    );
  }
}