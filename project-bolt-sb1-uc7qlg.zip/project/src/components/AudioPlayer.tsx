import React, { useRef, useState, useEffect } from 'react';
import { Download, Play, Pause } from 'lucide-react';

interface AudioPlayerProps {
  audioUrl: string | null;
  onDownload: () => void;
}

export default function AudioPlayer({ audioUrl, onDownload }: AudioPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateProgress = () => {
      const value = (audio.currentTime / audio.duration) * 100;
      setProgress(value || 0);
    };

    audio.addEventListener('timeupdate', updateProgress);
    audio.addEventListener('ended', () => setIsPlaying(false));

    return () => {
      audio.removeEventListener('timeupdate', updateProgress);
      audio.removeEventListener('ended', () => setIsPlaying(false));
    };
  }, []);

  const togglePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  if (!audioUrl) return null;

  return (
    <div className="w-full max-w-xl bg-white p-6 rounded-lg shadow-md">
      <audio ref={audioRef} src={audioUrl} className="hidden" />
      <div className="flex items-center justify-between gap-4">
        <button
          onClick={togglePlayPause}
          className="p-3 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors"
        >
          {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
        </button>
        <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
          <div 
            className="h-full bg-blue-500 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
        <button
          onClick={onDownload}
          className="p-3 rounded-full bg-green-500 text-white hover:bg-green-600 transition-colors"
        >
          <Download className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
}